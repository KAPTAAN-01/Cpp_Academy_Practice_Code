// ResturanBill&Menu-with-Loops.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include<iostream>
using namespace std;
int main()
{
    int key, quantity, paymentKey;
    char choise;
    double bill, tax;
    double cart = 0;

    
    cout << "         %%%| Welcome to the Riphah International Hotel |%%% \n ";
    do {
        cout << "         Menu of Resturant" << endl;
        cout << "         +------------------------------------------------+" << endl;
        cout << "         | Item Name        | Item Price /-  |   Item Key |" << endl;
        cout << "         | Zingger Burger   |     380        |      1     |" << endl;
        cout << "         | Shami Burger     |     150        |      2     |" << endl;
        cout << "         | XLarge Pizza     |     1950       |      3     |" << endl;
        cout << "         | Large Pizza      |     1650       |      4     |" << endl;
        cout << "         | Medium Pizza     |     1350       |      5     |" << endl;
        cout << "         | Small Pizza      |     1050       |      6     |" << endl;
        cout << "         | Fries            |     120        |      7     |" << endl;
        cout << "         | Regular Drinks   |     80         |      8     |" << endl;
        cout << "         +------------------------------------------------+" << endl;

        cout << "         Enter the key of Item: ";
        cin >> key;

        switch (key) {
         case 1:
             cout << "         Enter the Quantity of Zingger Burger: ";
             cin >> quantity;
             cart += (quantity * 380);
             break;
         case 2:
             cout << "         Enter the Quantity of Shami Burger: ";
             cin >> quantity;
             cart += (quantity * 150);
             break;
         case 3:
             cout << "         Enter the Quantity of XLarge Pizza: ";
             cin >> quantity;
             cart += (quantity * 1950);
             break;
         case 4:
             cout << "         Enter the Quantity of Large Pizza: ";
             cin >> quantity;
             cart += (quantity * 1650);
             break;
         case 5:
             cout << "         Enter the Quantity of Medium Pizza: ";
             cin >> quantity;
             cart += (quantity * 1350);
             break;
         case 6:
             cout << "         Enter the Quantity of Small Pizza: ";
             cin >> quantity;
             cart += (quantity * 1050);
             break;
         case 7:
             cout << "         Enter the Quantity of Fries: ";
             cin >> quantity;
             cart += (quantity * 120);
             break;
         case 8:
             cout << "         Enter the Quantity of Regular Bottels: ";
             cin >> quantity;
             cart += (quantity * 80);
             break;
         default:
             cout << "         Please Enter a Valid Key";
        }
        cout << "         Your Selected Item is Addeded in to the cart.\n         If you want to purchase some more items than press Y other wise any Key: ";
        cin >> choise;

    } while (choise == 'Y' || choise == 'y');
    
    cout << "         Choose the payment method\n";
    cout << "         -------------------------------------" << endl;
    cout << "         | Method         |    Tax   |   Key |" << endl;
    cout << "         | Online/Card    |    06%   |   1   |" << endl;
    cout << "         | Cash           |    16%   |   2   |" << endl;
    cout << "         -------------------------------------" << endl;

    do {
        cout << "         Enter the Key of Payment Method:";
        cin >> paymentKey;
             
        switch (paymentKey) {
        case 1:
            tax = cart * 0.06;
            cout << "         -------------------------------" << endl;
            cout << "         | Your Bill     |   " << cart << "Rs " << endl;
            cout << "         | Tax on Bill   |    " << tax << "Rs " << endl;
            cout << "         | Total Bill    |   " << cart + tax << "Rs " << endl;
            cout << "         -------------------------------" << endl;
            break;
        case 2:
            tax = cart * 0.16;
            cout << "                           -------------------------------" << endl;
            cout << "                           | Your Bill     |   " << cart << "Rs " << endl;
            cout << "                           | Tax on Bill   |    " << tax << "Rs " << endl;
            cout << "                           | Total Bill    |   " << cart + tax << "Rs " << endl;
            cout << "                           -------------------------------" << endl;
            break;
        default:
            cout << "         Sir Please enter the valid KEY of Payment Methid." << endl;
        }
        
    } while (paymentKey != 1 && paymentKey != 2);
    


        cout << "         ********** **    **      ******      ****     **  **   **         **       **    ******     **    **" << endl;
        cout << "            **      **    **     **    **     ** **    **  **  **           **     **   **      **   **    **" << endl;
        cout << "            **      ********    **      **    **  **   **  *****              **  **   **        **  **    **" << endl;
        cout << "            **      **    **   ** ****** **   **   **  **  ** **               ****    **        **  **    **" << endl;
        cout << "            **      **    **  **          **  **    ** **  **  **               **      **      **   **    **" << endl;
        cout << "            **      **    ** ***          *** **     ****  **   **              **       ********     ****** " << endl;
        cout << endl;
        cout << "                                      *******      ******    ******      " << endl;
        cout << "                                      **         **      **  **   **     " << endl;
        cout << "                                      *****     **        ** **   **     " << endl;
        cout << "                                      **        **        ** ******      " << endl;
        cout << "                                      **         **      **  **   ***    " << endl;
        cout << "                                      **          ********   **     ***  " << endl;
        cout << endl;
        cout << "                   ******   **   **    *******    *********  ********  ******   ****    **    ****** " << endl;
        cout << "                   **       **   **   **     **   **     **  **    **    **     ** **   **   **      " << endl;
        cout << "                   ******   *******  **       **  *********  ********    **     **  **  **   **  *** " << endl;
        cout << "                       **   **   **   **     **   **         **          **     **   ** **   **   ** " << endl;
        cout << "                   ******   **   **    *******    **         **        ******   **    ****    ****** " << endl;

        return 0;
}


